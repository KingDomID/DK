apt update

apt upgrade

apt install git

apt install python3-pip

pip3 install rsa

pip3 install thrift==0.11.0

pip3 install requests

pip3 install bs4

pip3 install gtts

pip3 install pytz

pip3 install humanfriendly

pip3 install googletrans

git clone https://github.com/NIGHTBATv1/55555

cd 55555

python3 pb.py
